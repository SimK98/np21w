#include <stdio.h>

typedef union tag_mmreg {
    uint8_t   b[8];
    uint16_t  w[4];
    uint32_t  d[2];
} mmreg;

int main(void) {
	mmreg datain1 __attribute__((aligned (16)));
	mmreg datain2 __attribute__((aligned (16)));
	mmreg dataout __attribute__((aligned (16)));
	datain1.d[0] = 0x11223344;
	datain1.d[1] = 0x55667788;
	datain2.d[0] = ~datain1.d[0];
	datain2.d[1] = 0xf0f0f0f0 & ~datain1.d[1];
	
	printf("MMX TEST\n");
	
	printf("in1: %x %x %x %x\n", datain1.w[0], datain1.w[1], datain1.w[2], datain1.w[3]);
	printf("in2: %x %x %x %x\n", datain2.w[0], datain2.w[1], datain2.w[2], datain2.w[3]);
	printf("PADDB in1,in2\n");
	
	__asm volatile(
	 ".arch core2;"
	 "movq %1,%%mm0;"
	 "movq %2,%%mm1;"
	 "paddb %%mm1,%%mm0;"
	 "movq %%mm0,%0;"
	 ".arch i286"
	 : "+m"(dataout) : "m"(datain1),"m"(datain2));
	
	printf("out: %x %x %x %x\n", dataout.d[0], dataout.d[1], dataout.w[2], dataout.w[3]);
	
	return 0;
}