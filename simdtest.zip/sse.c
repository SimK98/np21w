#include <stdio.h>

typedef union tag_xmmreg {
    uint8_t   b[16];
    uint16_t  w[8];
    uint32_t  d[4];
    uint64_t  q[2];
    float  f32[4];
    double  f64[2];
} xmmreg;

int main(void) {
	unsigned long cr0;
	unsigned long cr4;
	xmmreg datain __attribute__((aligned (16)));
	xmmreg dataout __attribute__((aligned (16)));
	datain.f32[0] = 1.0f;
	datain.f32[1] = 2.0f;
	datain.f32[2] = 3.0f;
	datain.f32[3] = 4.0f;
	
	printf("SSE TEST\n");
	
	printf("Address of datain: 0x%x\n", &datain);
	printf("Address of dataout: 0x%x\n", &dataout);
	
	__asm volatile(
	 ".arch pentiumiii;"
	 "mov %%cr4,%%eax;"
	 "mov %%eax,%0;"
	 : "+m"(cr4));
	
	printf("Current CR4: 0x%x\n", cr4);
	
	if((cr4 & 0x200)!=0x200){
		printf("Set CR4\n");
		__asm volatile(
		 ".arch pentiumiii;"
		 "mov %%cr4,%%eax;"
		 "or $0x200,%%eax;"
		 "mov %%eax,%%cr4;" : "+m"(dataout) : "m"(datain));
	}
		
	__asm volatile(
	 ".arch pentiumiii;"
	 "mov %%cr4,%%eax;"
	 "mov %%eax,%0;"
	 : "+m"(cr4));
	
	printf("Changed CR4: 0x%x\n", cr4);
	
	printf("in: %f %f %f %f\n", datain.f32[0], datain.f32[1], datain.f32[2], datain.f32[3]);
	printf("SQRTPS in\n");
	
	__asm volatile(
	 ".arch pentiumiii;"
	 "movaps %1,%%xmm0;"
	 "sqrtps %%xmm0,%%xmm1;"
	 "movaps %%xmm1,%0;"
	 : "+m"(dataout) : "m"(datain));
	
	printf("out: %f %f %f %f\n", dataout.f32[0], dataout.f32[1], dataout.f32[2], dataout.f32[3]);
	
	return 0;
}